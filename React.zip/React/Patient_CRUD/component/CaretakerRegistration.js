import React, { Component } from 'react';
import PatientService from '../Services/PatientService';
import 'animate.css'
import LoginCSS from './login.module.css';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {VscError} from 'react-icons/vsc';
import { BiCheckCircle } from 'react-icons/bi';



class CaretakerRegisterComponent extends Component {
    constructor(props) {
        super(props);

        this.state = {

            id: this.props.match.params.id,
            caretaker_name: '',
            caretaker_pwd: '',
            caretaker_email: '',
            caretaker_gender: '',
            caretaker_age: '',
            caretaker_phone: '',
            caretaker_location: '',
            caretaker_profile: '',
            //profession:'',
            profileoptions: [],
            caretaker_exp: '',
            charges: ''

        }

        this.changeCaretaker_nameHandler = this.changeCaretaker_nameHandler.bind(this);
        this.changeCaretaker_pwdHandler = this.changeCaretaker_pwdHandler.bind(this);
        this.changeCaretaker_emailHandler = this.changeCaretaker_emailHandler.bind(this);
        this.changeCaretaker_genderHandler = this.changeCaretaker_genderHandler.bind(this);
        this.changeCaretaker_ageHandler = this.changeCaretaker_ageHandler.bind(this);
        this.changeCaretaker_phoneHandler = this.changeCaretaker_phoneHandler.bind(this);
        this.changeCaretaker_locationHandler = this.changeCaretaker_locationHandler.bind(this);
        this.changeCaretaker_profileHandler = this.changeCaretaker_profileHandler.bind(this);
        this.changeCaretaker_expHandler = this.changeCaretaker_expHandler.bind(this);
        this.changeChargesHandler = this.changeChargesHandler.bind(this);


        this.createCaretaker = this.createCaretaker.bind(this);
        this.cancel = this.cancel.bind(this);
    }

    componentDidMount() {
        PatientService.createCaretaker().then((res => {
            this.setState({ employees: res.data });
        }));
        PatientService.dropdownCaretaker().then(res => {
            this.setState({ profileoptions: res.data })
        })

    }


    createCaretaker(event) {
        let employee = {
            caretaker_name: this.state.caretaker_name, caretaker_pwd: this.state.caretaker_pwd,
            caretaker_email: this.state.caretaker_email, caretaker_gender: this.state.caretaker_gender,
            caretaker_age: this.state.caretaker_age, caretaker_phone: this.state.caretaker_phone,
            caretaker_location: this.state.caretaker_location, caretaker_profile: this.state.caretaker_profile,
            caretaker_exp: this.state.caretaker_exp, charges: this.state.charges, usertype: 'caretaker'
        }
        console.log('employee =>' + JSON.stringify(employee));
        PatientService.createCaretaker(employee).then(res => {
           // alert("Registration Successfull!!")
           toast.success(<div><BiCheckCircle />Registration Successfully Completed!!</div>, {
            position: "top-center",
            autoClose: 3000,
            hideProgressBar: true,
            pauseOnHover: false,
          });
          

            console.log("After Register, data returned is " + res.data);
            this.props.history.push('/caretakerlogin');//routing to caretakerList page
        });
        event.preventDefault();
    }


    changeCaretaker_nameHandler(event) {
        this.setState({ caretaker_name: event.target.value });
    }

    changeCaretaker_pwdHandler(event) {
        this.setState({ caretaker_pwd: event.target.value });
    }


    changeCaretaker_emailHandler(event) {
        this.setState({ caretaker_email: event.target.value });
    }

    changeCaretaker_genderHandler(event) {
        this.setState({ caretaker_gender: event.target.value });
    }
    changeCaretaker_ageHandler(event) {
        this.setState({ caretaker_age: event.target.value });
    }
    changeCaretaker_phoneHandler(event) {
        this.setState({ caretaker_phone: event.target.value });
    }
    changeCaretaker_locationHandler(event) {
        this.setState({ caretaker_location: event.target.value });
    }
    changeCaretaker_profileHandler(event) {
        this.setState({ caretaker_profile: event.target.value });
    }
    changeCaretaker_expHandler(event) {
        this.setState({ caretaker_exp: event.target.value });
    }
    changeChargesHandler(event) {
        this.setState({ charges: event.target.value });
    }


    cancel() {
        this.props.history.push('/');
    }




    render() {

        const mystyle = {
            backgroundImage: 'url(care2.jpg)',
            backgroundPosition: "center",
            backgroundSize: "cover",
            height: "200vh",
            color: "white",
            padding: "40px",
            Width: "300%",

        };
        const style1 = {
           // backgroundColor: "rgba(210, 166, 121, 0.7000)",
           backgroundColor: "rgba(230, 230, 230, 0.7000)",
            padding: "30px",
            width: '900px',
            borderRadius: "90px",
            color: "black"
        };
        return (
            <div style={mystyle}>
                <br /><br />
                <h5 className="text-center" style={{ color: 'white', fontfamily: "Georgia, 'Times New Roman', Times, serif", fontSize: '40px', textAlign: 'bottom',background: 'linear-gradient(to bottom, #0099cc 0%, #ffffff 100%)', width: '800px', height: '70px', fontWeight: 'bold', fontFamily: 'revert', marginLeft: '500px', borderRadius: '50px', marginBottom: '30px' }}>CARETAKER REGISTRATION</h5>
                <center>
                    <div className="Container animate__animated animate__fadeInDown" style={style1}>
                        <div className="row">
                            <div >

                                <div className="card-body">
                                    <form onSubmit={this.createCaretaker}>

                                        <div class="col-md-10">
                                            <div className="" >
                                                <label>Your Name</label>
                                                <input placeholder="Caretaker Name" name="caretaker_name" required className="form-control" value={this.state.caretaker_name} onChange={this.changeCaretaker_nameHandler} style={{ color: 'black', fontFamily: 'sans-serif', fontSize: '25px' }} />
                                            </div>
                                            <div class="row">
                                               

                                                <div className="form-group col-md-6">
                                                    <label>Your Password</label>
                                                    <input placeholder="Caretaker pwd" name="caretaker_pwd" required className="form-control" value={this.state.caretaker_pwd} onChange={this.changeCaretaker_pwdHandler} style={{ color: 'black',  fontFamily: 'sans-serif', fontSize: '25px' }} />

                                                </div>
                                                <div className="form-group col-md-6">
                                                    <label>Your Email</label>
                                                    <input placeholder="Caretaker Email" type="email" name="caretaker_email" required className="form-control" value={this.state.caretaker_email} onChange={this.changeCaretaker_emailHandler} style={{ color: 'black',  fontFamily: 'sans-serif', fontSize: '25px' }} />
                                                </div>
                                            </div>

                                            <div class="row">

                                                <div className="form-group col-md-6">
                                                    <label>Your Gender</label>
                                                    <input placeholder="Caretaker Gender" name="caretaker_gender" required className="form-control" value={this.state.caretaker_gender} onChange={this.changeCaretaker_genderHandler} style={{ color: 'black', fontFamily: 'sans-serif', fontSize: '25px' }} />
                                                </div>


                                                <div className="form-group col-md-6">
                                                    <label>Your Age</label>
                                                    <input placeholder="Caretaker Age" name="caretaker_age" required className="form-control" value={this.state.caretaker_age} onChange={this.changeCaretaker_ageHandler} style={{ color: 'black', fontFamily: 'sans-serif', fontSize: '25px' }} />
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div className="form-group col-md-6">
                                                    <label>Your Phone</label>
                                                    <input placeholder="Caretaker Phone" name="caretaker_phone" required className="form-control" value={this.state.caretaker_phone} onChange={this.changeCaretaker_phoneHandler} style={{ color: 'black',  fontFamily: 'sans-serif', fontSize: '25px' }} />
                                                </div>

                                                <div className="form-group col-md-6">
                                                    <label>Your location</label>
                                                    <input placeholder="Caretaker Location" name="caretaker_location" required className="form-control" value={this.state.caretaker_location} onChange={this.changeCaretaker_locationHandler} style={{ color: 'black',  fontFamily: 'sans-serif', fontSize: '25px' }} />
                                                </div>
                                            </div>
                                            <br />


                                            <div className="">
                                                <label>Choose CareType</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                <select name="caretaker_profile" value={this.state.profession} required onChange={this.changeCaretaker_profileHandler}>
                                                    <option >Choose patient</option>
                                                    {
                                                        this.state.profileoptions.map(
                                                            profileoptions =>
                                                                <option value={`${profileoptions.profession}`}>{profileoptions.profession}</option>
                                                        )
                                                    }

                                                </select>
                                            </div><br />

                                            <div class="row">
                                                <div className="form-group col-md-6">
                                                    <label>Your Experience </label>
                                                    <input placeholder="Caretaker Experience" name="caretaker_exp" required className="form-control" value={this.state.caretaker_exp} onChange={this.changeCaretaker_expHandler} style={{ color: 'black', fontFamily: 'sans-serif', fontSize: '25px' }} />
                                                </div>
                                                <br />
                                                <div className="form-group col-md-6">
                                                    <label>Your Charges per hours</label>
                                                    <input placeholder="Charges" name="charges" required className="form-control" value={this.state.charges} onChange={this.changeChargesHandler} style={{ color: 'black', fontFamily: 'sans-serif', fontSize: '25px' }} />
                                                </div>
                                            </div>

                                        </div>
                                        
                                        <button className="btn btn-success" style={{ marginLeft: "40px", fontSize: '25px', fontFamily: 'sans-serif', width: '150px', height: '60px', borderRadius: '20px', marginTop: '10px' }}>Register</button>
                                        <button className="but btn-danger" onClick={this.cancel} style={{ marginLeft: "40px", fontSize: '25px', fontFamily: 'sans-serif', width: '150px', height: '60px', borderRadius: '20px' }}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </center>
            </div>

        );
    }

}

export default CaretakerRegisterComponent;
