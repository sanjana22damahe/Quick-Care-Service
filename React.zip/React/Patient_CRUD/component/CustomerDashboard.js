import React,{Component} from 'react';
import { Container , Carousel} from 'react-bootstrap';
import PatientService from '../Services/PatientService';
import image1 from './image/image3.jpg';
import Menu from "./Menu";
import './myStyle.css'

class CustomerDashboard extends Component
{

 

    render(){
        const style1 = {
            background: "linear-gradient(to bottom, #ccccff 0%, #993399 100%)",
            padding:"70px",
            borderRadius: "10px",
            color:"black"
           
           
          };

    

        return(
          <body>
           
           <div style={{marginTop:'80px'}}>
                    <Carousel >
                    <Carousel.Item interval={1100}>
                        <img height="600px" width="300px" margin="auto" className="d-block w-100" src="nurse.jpg" alt="1st slide" />
                        <Carousel.Caption><h5 style={{fontSize:'35px',fontWeight:'bold',color:'black'}}>BABYSITTER</h5></Carousel.Caption>
                    </Carousel.Item>

                    <Carousel.Item interval={1100}>
                        <img  height="600px" width="300px" margin="auto" className="d-block w-100" src="physio4.jpg" alt="2nd slide" />
                        <Carousel.Caption><h5 style={{fontSize:'35px',fontWeight:'bold',color:'black'}}>PHYSIOTHERAPIST</h5></Carousel.Caption>
                    </Carousel.Item>

                    <Carousel.Item interval={1100}>
                        <img  height="600px"  width="300px" margin="auto" className="d-block w-100" src="nanny2.jpg" alt="3rd slide" />
                        <Carousel.Caption><h5 style={{fontSize:'35px',fontWeight:'bold',color:'black'}}>NANNY</h5></Carousel.Caption>
                    </Carousel.Item>
                    <Carousel.Item interval={1100}>
                        <img  height="600px"  width="300px" margin="auto" className="d-block w-100" src="elderly1.jpg" alt="4rd slide" />
                        <Carousel.Caption><h5 style={{fontSize:'35px',fontWeight:'bold',color:'black'}}>ELDERLY CAREGIVER</h5></Carousel.Caption>
                    </Carousel.Item>

                    <Carousel.Item interval={1100}>
                        <img  height="600px"  width="300px" margin="auto" className="d-block w-100" src="nurse4.jpg" alt="5rd slide" />
                        <Carousel.Caption><h5 style={{fontSize:'35px',fontWeight:'bold',color:'black'}}>NURSE</h5></Carousel.Caption>
                    </Carousel.Item>
                </Carousel>
                </div>

                <div style={{marginTop:'100px'}}>
                <h5 style={{marginTop:'100px',marginLeft:'130px',fontSize:'50px',fontweight:'bold'}}>More Than Caregivers</h5>
       <p >Having an in-home caregivers extends further than receiving necessary care. Our caregivers provide companionship through building relationships with clients. With Compassion Network’s partners, you will never have a stranger in your home. We will match you with a qualified caregiver you feel comfortable being around. </p>
                </div>

                <div style={{marginTop:'100px'}}>
                <h5 style={{marginTop:'100px',marginLeft:'130px',fontSize:'50px',fontweight:'bold'}}>Services we provide</h5>
                  <div class="row" style={{marginTop:'100px'}}>
                    <div class="col-md-4">
                      <h5 style={{fontSize:'35px',fontWeight:'bold'}}>PHYSIOTHERAPIST</h5>
                    <img  height="400px"  width="200px" margin="auto" className="d-block w-100" src="physio2.jpg" alt="5rd slide" />
                    <p style={{ textAlign: 'left' }}>Physiotherapy is treatment to restore, maintain, and make the most of a patient's mobility, function, and well-being. Physiotherapy helps through physical rehabilitation, injury prevention, and health and fitness. Physiotherapists get you involved in your own recovery.</p>
                    
                    </div>

                    <div class="col-md-4">
                      <h5 style={{fontSize:'35px',fontWeight:'bold'}}>BABYSITTER</h5>
                    <img  height="400px"  width="200px" margin="auto" className="d-block w-100" src="babysitter1.jpg" alt="5rd slide" />
                    <p style={{ textAlign: 'left' }}>A babysitter is typically someone who temporarily cares for children on behalf of the children's parents or guardians. A babysitter may also be referred to as a "sitter," and the most basic job description is that they take care of children of all ages who are in need of supervision on an as-needed basis.</p>
                    </div>

                    <div class="col-md-4">
                      <h5 style={{fontSize:'35px',fontWeight:'bold'}}>ELDERLY CAREGIVER</h5>
                    <img  height="400px"  width="200px" margin="auto" className="d-block w-100" src="elderly2.jpg" alt="5rd slide" />
                    <p style={{ textAlign: 'left' }}> Elderly care, or simply eldercare, is the fulfillment of the special needs and requirements that are unique to senior citizens. This broad term encompasses such services as assisted living, adult daycare, long-term care, nursing homes, hospice care, and home care.</p>
                    </div>

                  </div>


                  <div class="row"  style={{marginTop:'100px'}}>
                    <div class="col-md-6">
                    <h5 style={{fontSize:'35px',fontWeight:'bold'}}>NURSE</h5>
                    <img  height="400px"  width="80px" margin="auto" className="d-block w-100" src="nurse6.jpg" alt="5rd slide" />
                    <p style={{ textAlign: 'left' }}>Nurse will care for the sick or infirm specifically : a licensed health-care professional who practices independently or is supervised by a physician, surgeon, or dentist and who is skilled in promoting and maintaining health — compare licensed practical nurse, registered nurse.</p>
                    </div>

                    
                    <div class="col-md-6">
                    <h5 style={{fontSize:'35px',fontWeight:'bold'}}>NANNY</h5>
                    <img  height="400px"  width="80px" margin="auto" className="d-block w-100" src="nanny3.jpg" alt="5rd slide" />
                    <p style={{ textAlign: 'left' }}>This is usually someone who is fully invested in a child's development and well-being. Perhaps it’s a regular gig that best differentiates a nanny from a babysitter. Generally, a nanny will care for children full-time while both parents work. That usually means regular hours and a long-term contract.</p>
                    </div>
                  
                   
                  </div>
                </div>


          </body>
                      
        )

    }

}
export default CustomerDashboard