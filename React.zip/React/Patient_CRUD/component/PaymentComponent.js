import React, {Component} from 'react';
import PatientService from '../Services/PatientService';

class PaymentComponent extends Component
{
   constructor (props)
   {
       super(props);
       this.state={
           id:this.props.match.params.id,
            credit_cardno:'',
           cvv:'',
           expiry:'',
           nameoncard:'',
           caretaker_id:3,
           patient_id:1,
        }
       this.changecredit_cardnoHandler=this.changecredit_cardnoHandler.bind(this);
       this.changecvvHandler=this.changecvvHandler.bind(this);
       this.changeexpiryHandler=this.changeexpiryHandler.bind(this);
       this.changenameoncardHandler=this.changenameoncardHandler.bind(this);

       this.onAddPayment=this.onAddPayment.bind(this);
   }
   componentDidMount()
   {
    PatientService.Payment().then((res =>{
        this.setState ({employees:res.data});
    }));
   }
   onAddPayment(event)
   {
       let employee={caretaker_id:sessionStorage.getItem('caretaker_id'),patient_id:sessionStorage.getItem('patient_id'),caretaker_id:3,patient_id:1,credit_cardno:this.state.credit_cardno,cvv:this.state.cvv,expiry:this.state.expiry,nameoncard:this.state.nameoncard}
       console.log('employee =>'+ JSON.stringify(employee));
       PatientService.Payment(employee).then(res=>
        {
            alert("Your Payment is Successfully Done!!");
            console.log("After adding Payment, data returned is "+res.data);
            this.props.history.push ('/caretakerlist');//routing to caretakerList page
        });
     event.preventDefault();
   }
   changecredit_cardnoHandler(event)
   {
    this.setState({credit_cardno:event.target.value});
   }
   changecvvHandler(event)
   {
    this.setState({cvv:event.target.value});
   }
   changeexpiryHandler(event)
   {
    this.setState({expiry:event.target.value});
   }
   changenameoncardHandler(event)
   {
    this.setState({nameoncard:event.target.value});
   }

render()
{
    const style1 = {
        backgroundColor: "rgba(230, 230, 230, 0.7000)",
        padding:"40px",
        borderRadius: "10px",
        color:"black"
      };
    return(
<div >
    <br/><br/>
    <div className="container"  style={style1}>
    <div>
      
      <h1>Enter your Details</h1>
      <div>
      <input placeholder="Credit Card number" name="credit_cardno" value={this.state.credit_card} onChange={this.changecredit_cardnoHandler}/>
      </div><br/>
      <div>
      <input placeholder="cvv" name="cvv" value={this.state.cvv} onChange={this.changecvvHandler}/>
      </div><br/>
      <div>
      <input placeholder="expiry" name="expiry" value={this.state.expiry} onChange={this.changeexpiryHandler}/>
      </div><br/>
      <div>
      <input placeholder="Name On Card" name="nameoncard" value={this.state.nameoncard} onChange={this.changenameoncardHandler}/>
      </div><br/>
      <button className="btn btn-success" onClick={this.onAddPayment} align="center">Pay Rs.3000</button>
      </div>
    </div>
</div>
  )
}
}
export default PaymentComponent;