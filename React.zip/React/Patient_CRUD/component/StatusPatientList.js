import React,{Component} from 'react';
import { Container } from 'react-bootstrap';
//import EmployeeService from '../Services/EmployeeService';
import 'animate.css'
import PatientService from '../Services/PatientService'
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {VscError} from 'react-icons/vsc';
import { BiCheckCircle } from 'react-icons/bi';

class StatusPatientList extends Component
{
    constructor(props)
    {
        super(props);
        this.state={patients:[]}

       /* this.addPatient=this.addPatient.bind(this);
        this.editPatient=this.editPatient.bind(this);
        this.deletePatient=this.deletePatient.bind(this);
        this.viewPatient=this.viewPatient.bind(this);*/
    }
   /* deletePatient(id)
    {
        EmployeeService.deletePatient(id).then 
        (
            
            res => {this.setState({patients:this.state.patients.filter(patient=> patient.patient_id !== id)});

        }
        )

    }
    viewPatient(id)
    {
        this.props.history.push(`/view-patient/${id}`);
    }*/
    accept(id)
    {
        PatientService.AcceptedStatus(id);
        console.log("ListComponentid:"+id);
        //alert("You have accepted request successfully!!")
        toast.success(<div><BiCheckCircle />Patient Request Accepted Successfully!!</div>, {
            position: "top-center",
            autoClose: 3000,
            hideProgressBar: true,
            pauseOnHover: false,
          });

          this.props.history.push('/patient-history');
        
        //this.props.history.push(`/add-patient/${id}`);
    }
    componentDidMount()
    {
        PatientService.getPatientstatus(sessionStorage.getItem('caretaker_id')).then((res=>{
            this.setState({patients:res.data});
        }));
    }
   /* addPatient()
    {
        this.props.history.push('/feedback');
    }*/

    reject(id)
    {
        //alert("rejected successfully!!!")
        toast.error(<div ><VscError /> Patient Request Rejected Successfully!!</div>, {
            position: "top-center",
           
            hideProgressBar: false
          });
        PatientService.Rejectedstatus(id);
        this.props.history.push(`/Reason-Of-Rejection/${id}`);
        //this.props.history.push('/patient-history');
    }


    /*giveReason(id)
    {
        
        this.props.history.push(`/add-patient/${id}`);
    }*/
    render()
    {
        const mystyle={
            backgroundImage:'url(care2.jpg)',
            backgroundSize:"cover",
            height:"100vh",
            color:"white",
            padding:"40px",
            Width:"40%"

          
          };
          
        return(
           

            <div style={mystyle}>
                
                
                <h2 className="text-center" style={{color:'white',fontfamily: "Georgia, 'Times New Roman', Times, serif",fontSize:'40px',textAlign:'bottom',background: 'linear-gradient(to bottom, #ff9966 0%, #cc0066 100%)',width: '800px',height:'70px',fontWeight:'bold',fontFamily:'revert',marginLeft:'500px',borderRadius:'50px'}}>PATIENT REQUESTED STATUS</h2>
                
                
                <div className="row" style={{marginTop:'30px'}}>
                    <table className="table table-striped table-bordered  animate__animated animate__fadeInDown">
                        <thead>
                            <tr>
                            <th style={{color:'#ffcc99',fontWeight:'bold',background:'linear-gradient(to bottom, #660066 0%, #660033 100%)',fontFamily:'sans-serif',fontSize:'27px'}}>Patient ID</th>
                                <th style={{color:'#ffcc99',textAlign:'center',background:'linear-gradient(to bottom, #660066 0%, #660033 100%)',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'27px'}}> Patient Name</th>
                                <th style={{color:'#ffcc99',textAlign:'center',background:'linear-gradient(to bottom, #660066 0%, #660033 100%)',fontFamily:'sans-serif',fontSize:'27px'}}>Patient Location</th>
                                <th style={{color:'#ffcc99',textAlign:'center',background:'linear-gradient(to bottom, #660066 0%, #660033 100%)',fontFamily:'sans-serif',fontSize:'27px'}}>FromDate</th>
                                <th style={{color:'#ffcc99',textAlign:'center',background:'linear-gradient(to bottom, #660066 0%, #660033 100%)',fontFamily:'sans-serif',fontSize:'27px'}}>ToDate</th>
                                <th style={{color:'#ffcc99',textAlign:'center',background:'linear-gradient(to bottom, #660066 0%, #660033 100%)',fontFamily:'sans-serif',fontSize:'27px'}}>Caretype</th>
                                <th style={{color:'#ffcc99',textAlign:'center',background:'linear-gradient(to bottom, #660066 0%, #660033 100%)',fontFamily:'sans-serif',fontSize:'27px'}}>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.patients.map(
                                    patient=>
                                    <tr key={patient.patient_id}>
                                       
                                        <td style={{color:'white',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>{patient.patient_id}</td>
                                        <td style={{color:'white',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>{patient.patient_name}</td>
                                        <td style={{color:'white',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>{patient.patient_location}</td>
                                        <td style={{color:'white',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>{patient.from_date}</td>
                                        <td style={{color:'white',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>{patient.to_date}</td>
                                        <td style={{color:'white',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>{patient.caretype}</td>
                                        <td style={{color:'white',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>
                                            <td><button onClick={()=>this.accept(patient.patient_id)} className="btn btn-success" style={{marginLeft:"40px",fontSize:'25px',fontFamily:'sans-serif',width:'150px',height:'60px',borderRadius:'50%'}}>Accept</button> </td>
                                            <td><button onClick={()=>this.reject(patient.patient_id)} className="btn btn-danger" style={{marginLeft:"40px",fontSize:'25px',fontFamily:'sans-serif',width:'150px',height:'60px',borderRadius:'50%'}}>Reject</button> </td>
                                           
                                        </td>

                                    </tr>
                                )
                            }
                        </tbody>
                        </table>
                        </div>
                       </div>
                      
        )
                        
    }
}
export default StatusPatientList
  
