import React, {useState} from "react";
import {NavLink} from 'react-router-dom'
import axios from 'axios'
import PatientService from "../Services/PatientService";
import 'bootstrap/dist/css/bootstrap.min.css';
import ListPatientComponent from "./ListPatientComponent";
import 'animate.css'
import LoginCSS from './login.module.css';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {VscError} from 'react-icons/vsc';
import { BiCheckCircle } from 'react-icons/bi';


class CustomerLogin extends React.Component
{
  constructor(props)
  {
    super(props)
    
    this.state = {
     
      cust_email:"",
      cust_pwd:"",
      usertype:'',
     cust_id:''
     
     
 }
     this.handleChange = this.handleChange.bind(this); 
  this.Login=this.Login.bind(this);
 
 }
   
   handleChange(event)
    {

      
        const name = event.target.name;
        const value = event.target.value;
        this.setState ({ [name] :value});     
    }


    
   
     Login()
    {
      let LoginDetails={
        cust_email:this.state.cust_email,
        cust_pwd:this.state.cust_pwd,
        usertype:'customer'

     };
    
      PatientService.customerlogin(LoginDetails).then(res =>
        {
         console.log(res)
          if(res.data.cust_email==this.state.cust_email&&res.data.cust_pwd==this.state.cust_pwd&&res.data.usertype=='customer')
          {
            //alert("Valid User");
            toast.success(<div><BiCheckCircle /> Login Successfull!</div>, {
              position: "top-center",
              autoClose: 3000,
              hideProgressBar: true,
              pauseOnHover: false,
            });
            sessionStorage.setItem('cust_id',res.data.cust_id);
            sessionStorage.setItem('usertype',res.data.usertype);
            console.log("LoginComponentid:"+res.data.cust_name);
         
              //this.props.history.push(`/dashboard/${this.state.cust_email}`);
              this.props.history.push('/dashboard');
          }
          else if(res.data.cust_email=="Invalid")
          {
           // alert("Invalid Login Credentials,Please Enter Correct EmailID and Password");
           toast.error(<div ><VscError /> Invalid Login Credentials</div>, {
            position: "top-center",
           
            hideProgressBar: false
          });
          setTimeout(function () {
            window.location.replace('/customerlogin');
          }, 3000);


          }
       
        })

       

    }
    
   
 
    render(){

    
   return  (
 
		<body className={LoginCSS.custbody}>
		<div class="container  animate__animated animate__fadeInDown ">
		<div class="row">
		<div class="col-md-3"></div>
    
		<div   className={LoginCSS.mainform}   >

      <form>
    <div class="col-md-6">
		<h1 class="text-center" style={{fontFamily:"Georgia, 'Times New Roman', Times, serif" }}>User Login</h1>
  
    <img className={LoginCSS.loginlogo}  src="login1.png" />

		<input type="email" name="cust_email" placeholder="Enter Your Email ID" value={this.state.cust_email} onChange={this.handleChange}  className={LoginCSS.formlogin} required></input>
         
    <input type="password" name="cust_pwd" placeholder="Enter Your Password" value={this.state.cust_pwd} onChange={this.handleChange} className={LoginCSS.formlogin} required></input>
		
    <button type="button" onClick={this.Login} style={{marginTop:'24px',fontSize:'30px',width:'600px',fontfamily: "Georgia, 'Times New Roman', Times, serif'",marginLeft:'100px',color: 'aliceblue'}}  class="btn btn-success">Login</button>
	
		</div>
    </form>
   
	
		</div>
    <div class="col-md-3"></div>
   
		</div>
    </div>
		</body>
		
 
    
         )
        }
      }
        
export default CustomerLogin
