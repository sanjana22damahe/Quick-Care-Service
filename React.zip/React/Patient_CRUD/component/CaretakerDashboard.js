import React,{Component} from 'react';
import { Container } from 'react-bootstrap';
import PatientService from '../Services/PatientService';
import image1 from './image/image3.jpg';
import './myStyle.css'
import CaretakerMenu from "./CaretakerMenu";

class CaretakerDashboard extends Component
{

 

    render(){
        const style1 = {
            background: "linear-gradient(to bottom, #33ccff 0%, #ff99cc 100%)",
            padding:"70px",
            borderRadius: "10px",
            color:"black"
           
          };

    

        return(
          <body>
         
         <div>
          
            <div style={style1}>

            <section id="slider">
              
            <input type="radio" name="slider" id="s1"/>
            <input type="radio" name="slider" id="s2"/>
            <input type="radio" name="slider" id="s3" checked/>
            <input type="radio" name="slider" id="s4"/>
            <input type="radio" name="slider" id="s5"/>
            <label for="s1" id="slide1">
                <img src="nurse2.jpg" height="100%" width="100%"/>
            </label>
            <label for="s2" id="slide2">
            <img src="Babysitter.jpeg" height="100%" width="100%"/>
            </label>
            <label for="s3" id="slide3">
            <img src="caretaker1.jpg" height="100%" width="100%"/>
            </label>
            <label for="s4" id="slide4">
            <img src="nurse.jpg" height="100%" width="100%"/>
            </label>
            <label for="s5" id="slide5">
            <img src="nanny.jpg" height="100%" width="100%"/>
            </label>
          </section>   
          </div>
          </div>
          </body>
                      
        )

    }

}
export default CaretakerDashboard