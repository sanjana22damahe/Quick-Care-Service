import React, {Component} from 'react';
//import View from './viewpatient.module.css';
import View1 from './newView.module.css';
import 'animate.css'
import PatientService from '../Services/PatientService'
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {VscError} from 'react-icons/vsc';
import { BiCheckCircle } from 'react-icons/bi';

class ViewBookingComponent extends Component
{
    constructor (props)
    {
        super(props);
    this.state ={id : this.props.match.params.id, employee:{},
        patient_name:'',
        patientOptions:[]
       // caretaker_id:''
    }
    this.changePnameHandler=this.changePnameHandler.bind(this);
    //this.changecidHandler=this.changecidHandler.bind(this);
   this.bookCaretaker=this.bookCaretaker.bind(this);
   this.cancel=this.cancel.bind(this);
    //status:'',
    }
    componentDidMount()
    {
        PatientService.getBookCaretakerListById(this.state.id).then(res =>
        {
          this.setState ({employee: res.data});
        })

        PatientService.getPatientByIddrop(sessionStorage.getItem('cust_id')).then(res=>
            {
                this.setState({patientOptions: res.data})
            })

    }

    bookCaretaker(event)
    {
        let employee={patient_name:this.state.patient_name}
        console.log('employee =>'+ JSON.stringify(employee));
        PatientService.finalBook(this.state.id,employee).then(res=>
            {
                console.log(res.data);
                this.props.history.push('/BookingCaretaker');
            });
        PatientService.insertBooking(employee).then(res=>
            {
                //alert("Booking Successfull!!")
                toast.success(<div><BiCheckCircle />Caretaker Successfully Booked!!</div>, {
                    position: "top-center",
                    autoClose: 3000,
                    hideProgressBar: true,
                    pauseOnHover: false,
                  });
                console.log(res.data);
                this.props.history.push('/BookingCaretaker');
            }
            );
        event.preventDefault();
    }
    changePnameHandler(event){
        this.setState({patient_name:event.target.value});
    }
    

    cancel(){
        this.props.history.push('/BookingCaretaker');
    }

    check(){
        var x = document.getElementById("patient_name").selectedOptions[0].label;
        
          if(x == "Choose patient"){
            alert("Please select Patient.");
           }
        }

    render()
    {

        const mystyle={
            backgroundImage:'url(new1.jpg)',
            backgroundPosition:"center",
            backgroundSize:"cover",
            height:"100vh",
            color:"white",
            padding:"40px",
            Width:"300%",
         
          };

        const style1 = {
           // backgroundColor: "rgba(210, 166, 121, 0.7000)",
           backgroundColor: "rgba(230, 230, 230, 0.7000)",
            padding:"30px",
            width:'900px',
            borderRadius: "90px",
            color:"black",
            
          };
        return (
            <body className={View1.bgviewimg}>
                <div className="card col-md-8 offset-md-2 animate__animated animate__fadeInDown" style={style1} >
           <div >
               <br/><br/>
               <center>
                <div >
                    <h3 className="text-center" style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'30px',marginBottom:'40px'}}>View Caretaker Details</h3>
                    <div classname="card-body"align="left" >

                    <div className="offset-md-2">

                            <div className="row">
                            <div className="col-md-6" > <label style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>Caretaker ID : </label></div>
                            <div className="col-md-6" ><h5 style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>{this.state.employee.caretaker_id}</h5></div>
                        </div><br/>



                        <div className="row">
                            <div className="col-md-6" ><label style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>Caretaker Name : </label></div>
                            <div className="col-md-6" ><h5 style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>{this.state.employee.caretaker_name}</h5></div>
                        </div><br/>

                        <div className="row">
                        <div className="col-md-6" ><label style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>Email Id : </label></div>
                        <div className="col-md-6" > <h5 style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>{this.state.employee.caretaker_email}</h5></div>
                        </div><br/>

                        <div className="row">
                        <div className="col-md-6" ><label style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>Gender : </label></div>
                        <div className="col-md-6" ><h5 style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>{this.state.employee.caretaker_gender}</h5></div>
                        </div><br/>

                        <div className="row">
                        <div className="col-md-6" ><label style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}> Age : </label></div>
                        <div className="col-md-6" ><h5 style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>{this.state.employee.caretaker_age}</h5></div>
                        </div><br/>

                        <div className="row">
                        <div className="col-md-6" ><label style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>Phone number : </label></div>
                        <div className="col-md-6" ><h5 style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>{this.state.employee.caretaker_phone}</h5></div>
                        </div><br/>

                        <div className="row">
                        <div className="col-md-6" > <label style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>Caretaker profile: </label></div>
                        <div className="col-md-6" > <h5 style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>{this.state.employee.caretaker_profile}</h5></div>
                        </div><br/>

                        <div className="row">
                        <div className="col-md-6" > <label style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>Caretaker Location : </label></div>
                        <div className="col-md-6" ><h5 style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>{this.state.employee.caretaker_location}</h5></div>
                        </div><br/>

                        <div className="row">
                        <div className="col-md-6" > <label style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>Experience: </label></div>
                        <div className="col-md-6" > <h5 style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>{this.state.employee.caretaker_exp}</h5></div>
                        </div><br/>

                        <div className="row">
                        <div className="col-md-6" ><label style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>Hourly Charges : </label></div>
                        <div className="col-md-6" > <h5 style={{color:'black',fontWeight:'bold',fontFamily:'sans-serif',fontSize:'25px'}}>{this.state.employee.charges}</h5></div>
                        </div><br/>

                        
                        
                       
            </div>
            <div style={{marginLeft:'300px' ,width:'40px'}} >
                    <select  id="patient_name" name="patient_name"   onfocusout="check()" value={this.state.patient_name} onChange={this.changePnameHandler} required>
                        <option value="" >Choose patient</option>
                        {
                            this.state.patientOptions.map(
                            patientOption =>
                            <option value={`${patientOption.patient_name}`}>{patientOption.patient_name}</option>
                        )
                         }   
                       
                    </select>
                    </div>
     <br/>
            <div style={{marginLeft:'200px'}}>
            <button className="btn btn-success" onClick={this.bookCaretaker} style={{marginLeft:"40px",fontSize:'25px',fontFamily:'sans-serif',width:'150px',height:'60px',borderRadius:'20px'}}>Book</button>
            <button className="btn btn-danger" onClick={this.cancel} style={{marginLeft:"10px"}} style={{marginLeft:"40px",fontSize:'25px',fontFamily:'sans-serif',width:'150px',height:'60px',borderRadius:'20px'}}>Cancel</button>
            </div>
           
                    </div>
                </div>
                </center>
           </div>
           </div>
           </body>
        );
    }
}
export default ViewBookingComponent