package com.example.Quickcareservicee.model;

public class CareType {
	


    String profession;

 

    public String getProfession() {
        return profession;
    }

 

    public void setProfession(String profession) {
        this.profession = profession;
    }
    

 

}
 







