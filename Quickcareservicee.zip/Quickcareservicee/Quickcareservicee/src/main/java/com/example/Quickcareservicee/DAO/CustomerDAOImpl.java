package com.example.Quickcareservicee.DAO;



import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.Quickcareservicee.model.BookCaretakerList;
import com.example.Quickcareservicee.model.Caretaker;
import com.example.Quickcareservicee.model.CaretakerList;
import com.example.Quickcareservicee.model.Customer;
import com.example.Quickcareservicee.model.Patient;
import com.example.Quickcareservicee.model.Payment;
import com.example.Quickcareservicee.service.CustomerService;

public class CustomerDAOImpl {
	public DataSource dataSource() {
		DriverManagerDataSource dataSource=new DriverManagerDataSource();
		
		dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
		dataSource.setUrl("jdbc:mysql://localhost:3306/quickcare");
	    dataSource.setUsername("root");
	    dataSource.setPassword("99Jenny97San#");
	    return dataSource;
	}
	JdbcTemplate template=new JdbcTemplate(dataSource());
	
	/*public String Login(String uid,String password)
	{
	
		String sql="Select * from Login where uid=\""+uid+ "\" and password=\""+password+"\"";
		System.out.println("Given sql is "+sql);
		
		LoginRowMapper loginRowMapperobj=new LoginRowMapper();
		List<Login> loginobj=template.query(sql, loginRowMapperobj);
		System.out.println("Size of the List of objects retured are"+loginobj.size());
		if(loginobj.size()==0) {
			
			return "Invalid User";
		}
		else {
			//System.out.println("Valid user");
			return "Valid User";
		}
	}

	public String Login(Login login) {
		 String sql="Insert into login values (?,?)";
         System.out.println("SQL Query is :"+sql);
         
        if(template.update(sql,login.getUid(),login.getPassword())>0)
         {
             return "Registration done successfully";
         }
         else {
             return "Registration Failed!!";
         }
     
		
	}*/

	

	/*public Login byName(String name) {
		String query="select * from login where uid=?";
		@SuppressWarnings("deprecation")
		Login ac=template.queryForObject(query,new Object[] {name},new BeanPropertyRowMapper<>(Login.class));
		return ac;
	}

	public Login byId(Integer id) {
		String query="select * from login where id=?";
		@SuppressWarnings("deprecation")
		Login ac=template.queryForObject(query,new Object[] {id},new BeanPropertyRowMapper<>(Login.class));
		return ac;
	}

	public String delete(int id) {
		String query="delete from login where id = ?";
		
		if(template.update(query,id)>0) {
			return "List deleted";
		}
		return "Not Deleted";
	}*/

	
	

	
	/////////////CustomerLogin Valid user on frontend
	public String customerLogin(String cust_email, String cust_pwd,String usertype) {
		String sql="Select * from customer_details where cust_email=\""+cust_email +"\" and cust_pwd=\""+cust_pwd+"\"and usertype=\""+usertype+"";
		System.out.println("Given sql is "+sql);
		
		CustomerRowMapper customerRowMapperobj=new CustomerRowMapper();
		List<Customer> loginobj=template.query(sql, customerRowMapperobj);
		
		if(loginobj.size()==0) {
			System.out.println("Size of the List of objects retured are"+loginobj.size());
			return "Invalid User";
		}
		else {
			System.out.println("Valid user");
			return "Valid User";
		
		
		/*try {
			return(Customer)template.queryForObject(sql, customerRowMapperobj,cust_email,cust_pwd);
		}
		catch(EmptyResultDataAccessException ex)
		{
			return null;
		}*/
	}
	}

	public List<Customer> getAllLogin() {
		String sql="select * from customer_details";
		CustomerRowMapper customerRowMapperobj=new CustomerRowMapper();
		
		List<Customer> loginobj=template.query(sql, customerRowMapperobj);
		System.out.println(loginobj.get(0));
		return loginobj;
	}

	public List<Customer> getCustomerById(int cust_id) {
		String sql="select * from customer_details where cust_id=?";
		CustomerRowMapper customerRowMapperobj=new CustomerRowMapper();
		List<Customer> cust=template.query(sql, customerRowMapperobj,cust_id);
		return cust;
	}


	
//////////abhi
	/*public Customer custlogin(String cust_email,String cust_pwd) {
		
		System.out.println("Dao class"+cust_email);
		String sql="Select * from customer_details where cust_email=\""+cust_email +"\" and cust_pwd=\""+cust_pwd+"\"";
		CustomerRowMapper customerRowMapperobj=new CustomerRowMapper();
		
		List<Customer> login=template.query(sql, customerRowMapperobj);
		System.out.println("Dao return:");
		return login.get(0);
	}*/


	
	////////Working
public List<Customer> custlogin(String cust_email,String cust_pwd, String usertype) {
		
		System.out.println("Dao class"+cust_email);
		String sql="Select * from customer_details where cust_email=\""+cust_email +"\" and cust_pwd=\""+cust_pwd+"\"and usertype=\""+usertype+"\"";
		CustomerRowMapper customerRowMapperobj=new CustomerRowMapper();
		
		List<Customer> login=template.query(sql, customerRowMapperobj);
		System.out.println("Dao return:");
		return login;
	
	
	

}
///////////caretakerList
public List<CaretakerList> getCaretakerList(int cust_id) {
	String sql="select p.patient_name,c.caretaker_name,c.caretaker_location,p.caretype,p.status,b.reason_ofrejection from patient_details p join caretaker_details c on p.caretaker_id=c.caretaker_id join booking_details b on p.patient_id=b.patient_id where b.cust_id=?;";
	 System.out.println("Given SQL Query is :"+sql);
	 CaretakerListRowMapper caretakerListRowMapper= new CaretakerListRowMapper();
	 List<CaretakerList> caretakerListObj= template.query(sql, caretakerListRowMapper, cust_id);
	return caretakerListObj;
}


///////////Customer Registration
public String CustomerRegistration(Customer customer) {
	String sql="Insert into customer_details values (?,?,?,?,?,?,?,?)";
	 System.out.println("Given SQL Query is :"+sql);
	 
   if(template.update(sql,customer.getCust_id(),customer.getCust_name(),customer.getCust_pwd(),
	customer.getCust_email(),customer.getCust_phone(),customer.getCust_gender(),customer.getCust_location(),customer.getUsertype())>0)
	 {
		 return "Registration Successfull!!";
	 }
	 else {
		 return "Registration Failed!!";
	 }
}

///////////////////////Booking-5 functionality////////////////////////////////////

//////////////CaretakerList for Booking 
public List<BookCaretakerList> bookingList() {
	
	System.out.println("Dao found...");
	String query = "select caretaker_id,caretaker_name,caretaker_location,caretaker_profile from caretaker_details;";
	
	BookCaretakerListRowMapper brm = new BookCaretakerListRowMapper();
	return template.query(query, brm);
}


///////////////////View Selected caretakerDetails by caretaker_id
public Caretaker getListById(int caretaker_id) {
	
	List<Caretaker> list = caretakerAll();
	for(Caretaker caretaker : list)
	{
		if(caretaker.getCaretaker_id()==caretaker_id)
		{
			return caretaker;
		}
	}
	return null;
}

public List<Caretaker> caretakerAll() {
	System.out.println("All caretaker dao Found...");
	String query = "Select * from caretaker_details";
	CaretakerRowMapper caretakerRowMapper = new CaretakerRowMapper();
	return template.query(query, caretakerRowMapper);
}
/////////////////// End of View Selected caretakerDetails by caretaker_id


//////////DropDown Caretaker booking
public List<Map<String, Object>> dropdownpatients(int cust_id) {
	List<Map<String, Object>> rows = template.queryForList("select patient_name from patient_details where cust_id=?",
            new Object[] {cust_id});   
    return rows;
	
}


/////////Onclick of book///////////////
////////////////1. Update status Book caretaker////////////////////////////
public Object updateStatus(int caretaker_id,  Patient patient) {
	
	System.out.println("Inside dao.....");
	String sqlSelect = "UPDATE patient_details SET status = 'Pending' , caretaker_id=? WHERE patient_name=? " ;
	if((template.update(sqlSelect,  caretaker_id, patient.getPatient_name()))>0)
	{
		System.out.println("OK");
		return "updated";
	}
	return "error";
}
///////////2.Insert into booking table
public boolean insertBooking(Patient patient) {
	
	String sql="insert into booking_details (cust_id,caretaker_id,patient_id,status) select cust_id,caretaker_id,patient_id,status from patient_details where patient_name=?";
	
	System.out.println("Inside Dao...");
	if((template.update(sql, patient.getPatient_name())) > 0) {
		return true;
	}
	return false;
}

///////////////////////End of Booking-5 functionality////////////////////////////////////



////////////////////payment
public List<Payment> getAllPayment() {
    System.out.println("Inside DAO...");
    String sql = "select * from payment ;";
    PaymentRowMapper paymentRowMapper = new PaymentRowMapper();
    List<Payment> payment = template.query(sql, paymentRowMapper);
    return payment;
}



public String PaymentService(Payment payment) {
    System.out.println("Inside dao...");
    String sql = "Insert into payment value (?,?,?,?,?,?,?);";
    System.out.println("Dao implemented");
    if(template.update(sql, payment.getPayment_id(),payment.getCredit_cardno(),payment.getCvv(),payment.getExpiry(),payment.getNameoncard(),payment.getCaretaker_id(),payment.getPatient_id())>0)
    {
        return "Payment Successfull";
    }
    else
    {
        return "Payment Failed";
    }
        
}







}

