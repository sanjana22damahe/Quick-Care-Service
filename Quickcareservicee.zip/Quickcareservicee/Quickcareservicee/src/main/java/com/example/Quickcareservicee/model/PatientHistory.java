package com.example.Quickcareservicee.model;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class PatientHistory {
	    
		String patient_name;
		String patient_location;
		String status;

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public String getPatient_name() {
			return patient_name;
		}

		public void setPatient_name(String patient_name) {
			this.patient_name = patient_name;
		}

		public String getPatient_location() {
			return patient_location;
		}

		public void setPatient_location(String patient_location) {
			this.patient_location = patient_location;
		}

	
}
