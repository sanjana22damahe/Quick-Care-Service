package com.example.Quickcareservicee.model;

public class CaretakerList {
	
	//int cust_id;
		String patient_name;
		String caretaker_name;
		String caretaker_location;
		String caretype;
		String status;
		String reason_ofrejection;
		/*public int getCust_id() {
		return cust_id;
	}
	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}*/
		public String getPatient_name() {
			return patient_name;
		}
		public void setPatient_name(String patient_name) {
			this.patient_name = patient_name;
		}
		public String getCaretaker_name() {
			return caretaker_name;
		}
		public void setCaretaker_name(String caretaker_name) {
			this.caretaker_name = caretaker_name;
		}
		public String getCaretaker_location() {
			return caretaker_location;
		}
		public void setCaretaker_location(String caretaker_location) {
			this.caretaker_location = caretaker_location;
		}
		
		public String getCaretype() {
			return caretype;
		}
		public void setCaretype(String caretype) {
			this.caretype = caretype;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getReason_ofrejection() {
			return reason_ofrejection;
		}
		public void setReason_ofrejection(String reason_ofrejection) {
			this.reason_ofrejection = reason_ofrejection;
		}

}
