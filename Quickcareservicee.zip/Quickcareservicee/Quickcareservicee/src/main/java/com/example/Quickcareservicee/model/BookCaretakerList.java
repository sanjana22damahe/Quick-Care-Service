package com.example.Quickcareservicee.model;

public class BookCaretakerList {
	int caretaker_id;
	String caretaker_name;
	String caretaker_location;
	String caretaker_profile;
	public int getCaretaker_id() {
		return caretaker_id;
	}
	public void setCaretaker_id(int caretaker_id) {
		this.caretaker_id = caretaker_id;
	}
	public String getCaretaker_name() {
		return caretaker_name;
	}
	public void setCaretaker_name(String caretaker_name) {
		this.caretaker_name = caretaker_name;
	}
	public String getCaretaker_location() {
		return caretaker_location;
	}
	public void setCaretaker_location(String caretaker_location) {
		this.caretaker_location = caretaker_location;
	}
	public String getCaretaker_profile() {
		return caretaker_profile;
	}
	public void setCaretaker_profile(String caretaker_profile) {
		this.caretaker_profile = caretaker_profile;
	}
}
